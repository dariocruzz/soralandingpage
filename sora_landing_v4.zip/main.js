// ============================================
//  SORA — main.js v4 (Conversión / Senior)
// ============================================

const T = {
  es: {
    "nav.benefits":"Qué resolvemos", "nav.work":"Trabajo", "nav.services":"Servicios", "nav.about":"Nosotros", "nav.contact":"Hablemos hoy",
    "hero.label":"Estudio de producto digital",
    "hero.l1":"Apps que hacen", "hero.l2":"crecer tu negocio.",
    "hero.sub":"Dejá de perder tiempo y clientes por sistemas que no funcionan. Construimos la tecnología que tu negocio necesita para crecer sin límites.",
    "hero.ctaPrimary":"Quiero mi app", "hero.ctaSecondary":"Ver cómo trabajamos ↓",
    "s.benefits":"Propuesta de valor", "ben.intro":"Tu negocio compite por atención y eficiencia. Hacemos que ganes en ambas.",
    "ben.1.t":"Aumentás tus ventas", "ben.1.d":"Interfaces sin fricción pensadas para que tu cliente compre o contrate sin perderse en el camino.",
    "ben.2.t":"Automatizás procesos", "ben.2.d":"Reemplazamos tareas manuales, planillas y mensajes repetitivos por sistemas que operan 24/7 de forma autónoma.",
    "ben.3.t":"Ahorrás tiempo (y plata)", "ben.3.d":"Tu equipo deja de apagar incendios operativos y se enfoca en hacer crecer el negocio. La tecnología trabaja por ustedes.",
    "ben.4.t":"Tenés control total", "ben.4.d":"Paneles de gestión a medida. Datos claros, métricas en tiempo real y el control absoluto de tu operación en la palma de tu mano.",
    "s.work":"Trabajo probado",
    "p.velora.t1":"Gestión", "p.velora.t2":"Voz", "p.velora.t3":"IA",
    "p.live":"Operando a escala", "p.see":"Ver resultados reales",
    "cs.challenge":"El problema de negocio", "cs.velora.challenge":"Un comercio minorista perdía horas todos los días conciliando ventas, stock y facturación entre tres sistemas rotos. La operación manual no les permitía escalar.",
    "cs.solution":"La solución desarrollada", "cs.velora.solution":"Construimos una plataforma de gestión accionada por voz con IA profunda. Integró todo en un solo flujo, emitiendo facturas y descontando stock en tiempo real.",
    "cs.m1":"Ventas procesadas en el primer trimestre operando",
    "cs.m2":"Tiempo operativo ahorrado en tareas administrativas diarias",
    "cs.m3":"Fricción o curva de entrenamiento para los empleados",
    "cs.velora.quote":"“El impacto fue inmediato. En una semana redujimos los errores a cero y liberamos casi todo el tiempo que pasábamos cargando datos. Se pagó sola.”",
    "cs.velora.cite":"— Negocio minorista, AMBA",
    "s.services":"Nuestro expertise", "srv.intro":"Construimos infraestructura digital robusta. No parches.",
    "srv.s1.t":"Interfaces que convierten", "srv.s1.d":"Cada píxel está pensado para guiar al usuario a la acción. UI/UX enfocado en la conversión, sin fricciones que te hagan perder ventas.",
    "srv.s2.t":"Apps que no se rompen al escalar", "srv.s2.d":"Desarrollamos con stacks modernos y bases de datos preparadas para alto tráfico. Tu negocio crece, la app resiste.",
    "srv.s3.t":"Negocios en piloto automático", "srv.s3.d":"Conectamos IA, pasarelas de pago y facturación para que todo tu ciclo de negocio funcione sin intervención humana repetitiva.",
    "srv.s4.t":"Acompañamiento post-lanzamiento", "srv.s4.d":"No te entregamos el código y desaparecemos. Monitoreamos performance, iteramos y te ayudamos a crecer con datos reales.",
    "s.about":"Quiénes somos", "ab.title":"Expertos en producto digital, no improvisados.", "ab.desc":"Somos un equipo senior con más de una década construyendo tecnología que genera impacto real. Hemos trabajado lanzando startups exitosas y optimizando operaciones de empresas establecidas.",
    "ab.s1":"Años aportando valor digital", "ab.s2":"Foco en conversión y escalabilidad", "ab.s3":"Trato directo con los founders",
    "s.contact":"Empecemos", "ct.title":"Hagamos crecer tu negocio.", "ct.sub":"Escribinos ahora. Te respondemos hoy mismo para definir tu próximo gran paso. Cero fricción.",
    "ct.wa":"Hablemos por WhatsApp", "ct.mail":"hola@sora.studio",
    "ft.tagline":"Agencia de producto y escala digital · Buenos Aires", "ft.made":"Construido en Argentina para el mundo"
  },
  en: {
    "nav.benefits":"What we solve", "nav.work":"Work", "nav.services":"Services", "nav.about":"About us", "nav.contact":"Let's talk today",
    "hero.label":"Digital product studio",
    "hero.l1":"Apps that make", "hero.l2":"your business grow.",
    "hero.sub":"Stop losing time and clients due to broken systems. We build the technology your business needs to grow without limits.",
    "hero.ctaPrimary":"I want my app", "hero.ctaSecondary":"See how we work ↓",
    "s.benefits":"Value Proposition", "ben.intro":"Your business competes for attention and efficiency. We make you win at both.",
    "ben.1.t":"Increase your sales", "ben.1.d":"Frictionless interfaces designed so your customer buys or subscribes without getting lost along the way.",
    "ben.2.t":"Automate processes", "ben.2.d":"We replace manual tasks, spreadsheets, and repetitive messages with systems that operate autonomously 24/7.",
    "ben.3.t":"Save time (and money)", "ben.3.d":"Your team stops putting out operational fires and focuses on growing the business. Technology works for you.",
    "ben.4.t":"Total control", "ben.4.d":"Custom management dashboards. Clear data, real-time metrics, and absolute operation control in the palm of your hand.",
    "s.work":"Proven work",
    "p.velora.t1":"Management", "p.velora.t2":"Voice", "p.velora.t3":"AI",
    "p.live":"Operating at scale", "p.see":"See real results",
    "cs.challenge":"The business problem", "cs.velora.challenge":"A retail business lost days reconciling sales, inventory, and billing across three broken systems. Manual operation was stopping their scale.",
    "cs.solution":"The developed solution", "cs.velora.solution":"We built a voice-activated management platform with deep AI. It unified everything in one flow, issuing invoices and updating stock in real time.",
    "cs.m1":"Processed sales in the first operating quarter",
    "cs.m2":"Operational time saved in daily admin tasks",
    "cs.m3":"Friction or training curve for employees",
    "cs.velora.quote":"“The impact was immediate. In one week we reduced errors to zero and freed up almost all the time we spent entering data. It paid for itself.”",
    "cs.velora.cite":"— Retail business, Buenos Aires",
    "s.services":"Our expertise", "srv.intro":"We build robust digital infrastructure. Not patches.",
    "srv.s1.t":"Interfaces that convert", "srv.s1.d":"Every pixel is designed to guide the user to action. UI/UX focused on conversion, with no friction that makes you lose sales.",
    "srv.s2.t":"Apps that don't break when scaling", "srv.s2.d":"We develop with modern stacks and databases ready for high traffic. Your business grows, the app holds up.",
    "srv.s3.t":"Businesses on autopilot", "srv.s3.d":"We connect AI, payment gateways, and billing so your entire business cycle runs without repetitive human intervention.",
    "srv.s4.t":"Post-launch support", "srv.s4.d":"We don't just hand over the code and disappear. We monitor performance, iterate, and help you grow with real data.",
    "s.about":"Who we are", "ab.title":"Experts in digital products, not improvisers.", "ab.desc":"We are a senior team with over a decade building technology that generates real impact. We have worked launching successful startups and optimizing operations for established companies.",
    "ab.s1":"Years adding digital value", "ab.s2":"Focus on conversion and scalability", "ab.s3":"Direct handling with founders",
    "s.contact":"Let's start", "ct.title":"Let's grow your business.", "ct.sub":"Message us now. We'll reply today to define your next big step. Zero friction.",
    "ct.wa":"Talk via WhatsApp", "ct.mail":"hola@sora.studio",
    "ft.tagline":"Product & digital scaling agency · Buenos Aires", "ft.made":"Built in Argentina for the world"
  }
};

const lang = navigator.language?.toLowerCase().startsWith('en') ? 'en' : 'es';
function applyLang() {
  const t = T[lang];
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const k = el.dataset.i18n;
    if (t[k]) el.textContent = t[k];
  });
  document.documentElement.lang = lang;
  document.title = lang === 'en' ? 'Sora — Apps that grow your business' : 'Sora — Apps que hacen crecer tu negocio';
}

const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 40);
}, { passive: true });

const Hamburg = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
Hamburg.addEventListener('click', () => {
  Hamburg.classList.toggle('open');
  mobileMenu.classList.toggle('open');
});
mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
  Hamburg.classList.remove('open');
  mobileMenu.classList.remove('open');
}));

const ro = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('visible'); });
}, { threshold: 0.05, rootMargin: '0px 0px -20px 0px' });
document.querySelectorAll('.reveal').forEach(el => ro.observe(el));

document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const t = document.querySelector(a.getAttribute('href'));
    if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth' }); }
  });
});

document.addEventListener('DOMContentLoaded', applyLang);
